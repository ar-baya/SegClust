# SegClust Package

This is the Python 3 code implementation from the Pixel sampling by clustering paper
[Github Link](https://)
For accuratte technical description you can read 'Pixel sampling by clustering'. Here we include some examples....
